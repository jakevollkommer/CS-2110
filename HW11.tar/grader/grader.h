#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern FILE* file;

void deduct_points(int points, const char *tag, const char *message);
void add_points(int points, const char *tag, const char *message);

