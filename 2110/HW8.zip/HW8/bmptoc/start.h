#define START_WIDTH 160
#define START_HEIGHT 160
const unsigned short start_data[25600];
