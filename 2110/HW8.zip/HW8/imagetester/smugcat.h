#define SMUGCAT_WIDTH 160
#define SMUGCAT_HEIGHT 160
const unsigned short smugcat_data[25600];
