#define DEDDY_WIDTH 105
#define DEDDY_HEIGHT 150
const unsigned short deddy_data[15750];
