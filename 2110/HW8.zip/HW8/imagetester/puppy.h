#define PUPPY_WIDTH 150
#define PUPPY_HEIGHT 113
const unsigned short puppy_data[16950];
