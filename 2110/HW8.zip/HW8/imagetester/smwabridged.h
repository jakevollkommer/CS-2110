#define SMWABRIDGED_WIDTH 240
#define SMWABRIDGED_HEIGHT 160
const unsigned short smwabridged_data[38400];
